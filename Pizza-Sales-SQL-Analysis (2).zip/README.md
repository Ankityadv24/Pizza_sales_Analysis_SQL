# 🍕 Pizza Sales Analysis using SQL

This project analyzes transactional data from a fictional Pizza Hut-style restaurant using structured SQL queries to derive business insights from raw sales data.

## 📌 Objective
To use SQL to analyze pizza sales data and extract key insights on:
- Total orders and revenue
- Best-selling pizzas and sizes
- Revenue breakdown by category
- Order trends by time of day
- Business recommendations

## 🛠️ Tools & Technologies
- **MySQL** for querying relational data
- SQL features: `JOIN`, `GROUP BY`, `ORDER BY`, `SELECT`, `SUM`, `AVG`, `ROUND`
- Data from tables: `orders`, `order_details`, `pizzas`, `pizza_types`

## 🔍 Key Questions & Queries

| No. | Business Question | SQL Keyword Used |
|-----|-------------------|------------------|
| 1.  | Total number of orders | `COUNT(*)` |
| 2.  | Total revenue generated | `SUM(quantity * price)` |
| 3.  | Highest-priced pizza | `ORDER BY price DESC` |
| 4.  | Most common pizza size | `GROUP BY size` |
| 5.  | Top 5 most ordered pizza types | `TOP`, `SUM(quantity)` |
| 6.  | Total quantity by pizza category | `GROUP BY category` |
| 7.  | Order distribution by hour | `DATEPART(hour)` |
| 8.  | Category-wise pizza distribution | `GROUP BY category` |
| 9.  | Avg. pizzas ordered per day | `AVG()` on subquery |
| 10. | Top 3 pizzas by revenue | `SUM(quantity * price)` |
| 11. | % revenue by category | `SUM(...) / Total * 100` |

## 📊 Key Metrics

- **Total Orders:** 21,350  
- **Total Revenue:** $817,860.05  
- **Highest Priced Pizza:** Thai Chicken Pizza – $35.95  
- **Most Common Size:** Large  
- **Top 5 Ordered Pizzas:** Classic Pepperoni, BBQ Chicken, Hawaiian, Veggie Lovers, Margherita  
- **Top Categories by Quantity:** Classic  
- **Busiest Order Hours:** 6–8 PM  
- **Avg. Orders per Day:** ~68  

## 💡 Business Recommendations
- Promote top-performing pizza types (e.g., Classic Pepperoni)
- Optimize staffing between 6 PM and 9 PM
- Offer mid-week promotions to boost weekday sales
- Focus marketing efforts on Classic and Chicken categories

## 📁 Files in This Repo
- `queries/pizza_sales_queries.sql`: SQL script for all business questions
- `presentation/Pizza_Sales_Analysis_SQL_final.pptx`: Final PPT used for presenting insights
- `data/`: Placeholder folder for any datasets
- `visuals/`: (Optional) Graphs/charts if visualized using Python/Power BI

## ✍️ Author
**Ankit Yadav**  
_Github: [Ankityadv24](https://github.com/Ankityadv24)_

## 📢 License
This project is for educational and portfolio purposes.
